import pandas as pd
import numpy as np
from numpy import *
import torch
from src.utils import *
from src.model import *
from src.train import *

from sklearn.model_selection import  StratifiedKFold,KFold
from xgboost import XGBClassifier
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score

from scipy import interp

from statistics import mean, stdev




def get_parser():
    import argparse
    parser = argparse.ArgumentParser(description="DDAGDL")
    parser.add_argument("-d", "--dataset_name", default="H-dataset", type=str,
                        choices=["B-dataset", "C-dataset", "F-dataset"])
    parser.add_argument("-n", "--n_folds", default=10, type=int, choices=[5, 10, -1], help="cross valid fold num")
    parser.add_argument("--epochs", default=200, type=int)
    parser.add_argument("--epsilon", default=0.03, type=float, help="the value of delta")
    parser.add_argument("--embedding_dim", default=64, type=int)
    parser.add_argument("--layer_num", default=3, type=int)
    parser.add_argument("--lr", default=1e-1, type=float)
    parser.add_argument("--dropout", default=0.5, type=float)
    args = parser.parse_args()
    return args


from statistics import mean, stdev
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score

def main(config):
    path = './data/' + config["dataset_name"]
    
    # Positive samples
    Positive = pd.read_csv(path + '/DrDiNum.csv', header=None)
    n_pos = len(Positive)

    # Negative samples
    Adj = incidence_matrix(Positive)
    Negative = np.transpose(np.where(Adj.toarray() == 0))
    Negative = pd.DataFrame(Negative)
    Negative[1] = Negative[1] + max(Positive[0]) + 1
    
    # Balance negatives = positives
    Negative = Negative.sample(n=n_pos, random_state=18416)

    # Embedding
    Embedding = train(config)

    Positive[2] = 1
    Negative[2] = 0
    result = pd.concat([Positive, Negative]).reset_index(drop=True)

    X = pd.concat(
        [
            Embedding.loc[result[0].values.tolist()].reset_index(drop=True),
            Embedding.loc[result[1].values.tolist()].reset_index(drop=True)
        ],
        axis=1
    )
    Y = result[2]

    # DDA prediction
    aucs, auprs = [], []
    skf = StratifiedKFold(n_splits=config["n_folds"], random_state=0, shuffle=True)
    i = 0
    for train_index, test_index in skf.split(X, Y):     
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        Y_train, Y_test = Y.iloc[train_index], Y.iloc[test_index]

        model = XGBClassifier(n_estimators=999, n_jobs=-1)
        model.fit(np.array(X_train), np.array(Y_train))

        y_score_proba = model.predict_proba(np.array(X_test))[:, 1]

        # AUC
        fpr, tpr, _ = roc_curve(Y_test, y_score_proba)
        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)

        # AUPR
        aupr = average_precision_score(Y_test, y_score_proba)
        auprs.append(aupr)

        print("---------------------------------------------")
        print("fold = ", i)
        print("AUC:", roc_auc)
        print("AUPR:", aupr)
        print("---------------------------------------------\n")
        i += 1

    # Final results
    print("========== Final Results ==========")
    print("Mean AUC:", round(mean(aucs), 3))
    print("Std AUC:", round(stdev(aucs), 3))
    print("Mean AUPR:", round(mean(auprs), 3))
    print("Std AUPR:", round(stdev(auprs), 3))


    
if __name__=="__main__":
    args = get_parser()
    config = vars(args)
    print(config)
    main(config)
